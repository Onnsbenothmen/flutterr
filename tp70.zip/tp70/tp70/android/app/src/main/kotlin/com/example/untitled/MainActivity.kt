package com.example.tp70

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
