

class Student{
  String dateNais , nom , prenom ;
  int? id;
  Student(this.dateNais, this.nom , this.prenom , [this.id] );
}